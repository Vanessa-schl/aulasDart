void main(List<String> args) {
  
  var count = 1;

  while(count <= 10) {
    print(count++);
  }
}
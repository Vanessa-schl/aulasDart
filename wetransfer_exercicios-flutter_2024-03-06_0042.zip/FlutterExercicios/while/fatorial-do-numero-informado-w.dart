import 'dart:io';

void main() {
 print('Por favor, insira um número entre 2 e 10: ');

 String input = stdin.readLineSync()!;
 int numero = int.parse(input);

 if (numero < 2 || numero > 10) {
    print('O número deve estar entre 2 e 10.');
    return;
 }

 print('O fatorial de $numero é: ${calcularFatorial(numero)}');
}

int calcularFatorial(int numero) {
 int resultado = 1;
 int i = 1;

 while (i <= numero) {
    resultado *= i;
    i++;
 }

 return resultado;
}

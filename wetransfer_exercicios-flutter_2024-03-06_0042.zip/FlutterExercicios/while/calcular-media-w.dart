import 'dart:io';

void main() {
 print('Por favor, insira a nota das 10 turmas:');

 List<int> numeros = [];
 int i = 0; // Inicializa o contador

 while (i < 10) { // Loop while para solicitar as notas
    stdout.write('Nota turma ${i + 1}: ');
    String input = stdin.readLineSync()!;
    numeros.add(int.parse(input));
    i++; // Incrementa o contador
 }

 print('As notas foram: $numeros');

 // Calcula a soma das notas
 int soma = numeros.reduce((a, b) => a + b);

 // Calcula a média das notas
 double media = soma / numeros.length;

 print('A média das ${numeros.length} resultou em: $media');
}

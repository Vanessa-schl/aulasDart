
void main(List<String> args) {
 final List<int> numbers = List<int>.generate(100, (index) => index + 1);
 List<int> pares = [];
 int i = 0; // Inicializa o contador

 while (i < numbers.length) { // Loop while para verificar se o número é par
    if (numbers[i] % 2 == 0) {
      pares.add(numbers[i]);
    }
    i++; // Incrementa o contador
 }

 print(pares);
}

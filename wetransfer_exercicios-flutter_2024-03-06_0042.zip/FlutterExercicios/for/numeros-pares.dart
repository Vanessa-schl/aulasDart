
void main(List<String> args) {

  final List<int> numbers = List<int>.generate(100, (index) => index + 1);

// imprimir numeros pares
  print(numbers.where((number) => number % 2 == 0).toList());
}
import 'dart:io';

void main() {
 print('Menu de Opções');
 print('1. Opção 1');
 print('2. Opção 2');
 print('3. Opção 3');
 print('4. Opção 4');
 print('Digite o número da opção desejada:');
 
 var input = stdin.readLineSync();

 int inputNumber = int.tryParse(input ?? '0') ?? 0;

 switch (inputNumber) {
    case 1:
      print('Você escolheu a Opção 1');
      break;
    case 2:
      print('Você escolheu a Opção 2');
      break;
    case 3:
      print('Você escolheu a Opção 3');
      break;
    case 4:
      print('Você escolheu a Opção 4');
      break;
    default:
      print('Entrada inválida');
 }
}

import 'dart:io';

void main() {
 print('Por favor, insira 5 números: ');

 List<int> numeros = [];

 for (int i = 0; i < 5; i++) {
//outra forma de solicitar entrada no terminal
    stdout.write('Numero ${i + 1}: ');
    String input = stdin.readLineSync()!;
    numeros.add(int.parse(input));
 }

  print('Os números foram: $numeros');

//calcular o menor numero da lista
   int menor = numeros.reduce((a, b) => a < b ? a : b);

//calcula o maior numero da lista
   int maior = numeros.reduce((a, b) => a > b ? a : b);

  print('O menor número informado é: $menor, e o maior número é: $maior' );

}

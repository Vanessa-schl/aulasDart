import 'dart:io';

// variavel de ambiente dart: https://www.alura.com.br/artigos/flutter-como-configurar-o-ambiente-de-desenvolvimento

void main() {
 print('Por favor, insira a nota das 10 turmas:');

 List<int> numeros = [];

 for (int i = 0; i < 10; i++) {

//outra forma de solicitar entrada no terminal
    stdout.write('Nota turma ${i + 1}: ');

    String input = stdin.readLineSync()!;

    numeros.add(int.parse(input));
 }

  print('As notas foram: $numeros');

// para calcular a medida, podemos utilizar o reduce, que retorna um valor da lista, um resulado.
// mas tambem pode retornar uma lista, eu passando o index que quero
//tipo um .map filtrado

 // Calcula a soma das notas
 int soma = numeros.reduce((a, b) => a + b);

 // Calcula a média das notas
 double media = soma / numeros.length;


 print('A média das ${numeros.length} resultou em: $media');
}

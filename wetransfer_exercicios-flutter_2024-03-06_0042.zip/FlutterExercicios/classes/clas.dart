class Contact {

  String? name;
  String? email;
  String? phone;
}

void main(List<String> args) {
  //operador new é opção para criar/instanciar um objeto
  Contact c1 = Contact();
  Contact c2 = new Contact();

  c1.name = 'João';
  c1.email = 'joao@teste.com';
  c1.phone = '225588994';

  c2.name = 'Maria';
  c2.email = 'maria@teste.com';
  c2.phone = '4468734649';
}